---
name: Executive Precision
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#d0bcff'
  on-secondary: '#3c0091'
  secondary-container: '#571bc1'
  on-secondary-container: '#c4abff'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00885d'
  on-tertiary-container: '#000703'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

The design system projects absolute competence, sovereign security, and crystalline focus. Designed for C-suite leaders, knowledge directors, and high-velocity product operators, the visual aesthetic eliminates sensory clutter in favor of high-density clarity and decisive utility.

The philosophy merges **Precision Corporate Modernism** with **Atmospheric AI Glass**. The interface relies on razor-sharp layout structures, deep slate tones, and measured indigo-violet luminescence. AI interactions are never rendered as toy-like novelties; instead, they appear as responsive optical instruments—characterized by subtle perimeter refractive glows, directional surface light, and telemetry-grade metadata indicators. Every state conveys computational authority, grounded attribution, and executive polish.

## Colors

The palette operates on a calibrated slate foundation tuned for dark mode by default, preventing cognitive fatigue during prolonged deep-work workflows while ensuring crisp contrast ratios meeting WCAG AAA compliance.

- **Primary (`#6366F1` - Electric Indigo):** Anchors operational focal points, primary action triggers, active tabs, and primary system confirmations.
- **Secondary (`#8B5CF6` - Spectral Violet):** Reserved exclusively for generative intelligence states, continuous synthesis progress meters, inline neural prompt suggestions, and high-level reasoning indicators.
- **Tertiary (`#10B981` - Enterprise Emerald):** Encodes trust verification: grounded source citations, SOC2/enterprise privacy compliance badges, zero-data-retention tags, and verified cryptographic signatures.
- **Neutral (`#0F172A` - Obsidian Slate):** Forms the foundational chromatic baseline. Tints grade upward from deep bedrock `#090D16` to surface slate `#1E293B` and border-level `#334155`. Text scales from `#F8FAFC` (pure primary legibility) down to `#64748B` for subdued metadata.

### AI Luminance & Status Mapping
When AI is actively synthesizing or routing background context, border outlines shift from static slate (`#334155`) to a calibrated gradient transition between `#6366F1` and `#8B5CF6` with an accompanying 4px blurred radial ring. Grounded outputs display inline Tertiary Emerald metadata capsules indicating origin certainty.

## Typography

Typography establishes an uncompromising hierarchy of human thought and machine intelligence. 

- **Geist (Display & Headlines):** Delivers geometric precision, taut letter tracking, and an authoritative presence reminiscent of high-end executive dashboards and operating consoles.
- **Inter (Body & Interactive Text):** Guarantees optimal scanability for dense document summaries, multi-threaded communication, and multi-column workflow views.
- **JetBrains Mono (Metadata, Badges, Citations, & Verification Tags):** Injects technical rigor. All tokens relating to source grounding, confidence scores, token speeds, latency, and security statuses are set exclusively in this monospaced voice.

## Layout & Spacing

The structural layout utilizes a high-density, multi-pane productivity model engineered for desktop canvas workspaces and refactored for rapid mobile access.

### Desktop Form Factor (≥ 1280px)
- **Grid Architecture:** 12-column variable fluid grid framed by persistent 64px macro navigation. Content workspaces leverage fixed gutters (`1.5rem`) and structural margin offsets (`2.5rem`).
- **Tri-Pane Composition:** Left telemetry & navigation pane (260px fixed), primary contextual document/canvas workboard (fluid flex), and contextual right AI copilot sidebar (380px fixed).

### Tablet Form Factor (768px – 1279px)
- Gutters collapse to `1.25rem` and outer margins to `1.5rem`.
- The AI copilot sidebar folds into an off-canvas drawer invoked via floating micro-capsules or header triggers. Workspace maintains an 8-column layout.

### Mobile Form Factor (≤ 767px)
- Fluid single-column view with `1rem` margins and gutters.
- Visual elements adhere strictly to bottom-screen ergonomics: actions, filter tags, and AI query bars anchor to the bottom 40% of the viewport with a minimum tap target height of 44px.

## Elevation & Depth

Visual depth is achieved through layered structural dark tones, precise hairline borders, and translucent composite surfaces rather than traditional heavy drop shadows.

1. **Base Surface (Level 0 - Bedrock):** `#090D16` solid canvas background.
2. **Micro-Card Tiers (Level 1):** `#0F172A` with 1px border styled as `rgba(255, 255, 255, 0.08)`. No directional shadow.
3. **Elevated Panels & Flyouts (Level 2):** `#1E293B` at 85% opacity backed by `backdrop-filter: blur(16px)`. Border is `rgba(255, 255, 255, 0.12)`. Subtle ambient shadow: `0 8px 32px -4px rgba(0, 0, 0, 0.5)`.
4. **AI Active & Streaming States (Luminescence Mode):** Surfaces processing active generative tasks gain a perimeter illumination: `box-shadow: 0 0 0 1px #6366F1, 0 0 24px -2px rgba(139, 92, 246, 0.25)`.
5. **Modal & Critical Dialogue Overlays (Level 3):** Fixed centered presentation over `#050811` at 70% blur overlay, encased in double-stroke perimeter borders: interior `rgba(255, 255, 255, 0.15)`, exterior `rgba(0, 0, 0, 0.8)`.

## Shapes

The geometric silhouette system favors crisp, architectonic corners over friendly or playful roundness, maintaining a calibrated, high-efficiency tool posture.

- Standard UI primitives (buttons, inputs, micro-cards, and data cells) employ **Soft** radii (`0.25rem` / 4px).
- Larger modal surfaces, workspace splitters, and contextual flyouts scale to `rounded-lg` (`0.5rem` / 8px).
- The only shapes granted full continuous curvature (`9999px` capsule profiles) are status pills, ethical verification badges, and floating bottom-bar touch targets.

## Components

### Buttons
- **Primary:** Background `#6366F1`, label `#FFFFFF` in `body-md` (weight 500), border `1px solid rgba(255, 255, 255, 0.2)`. On hover, brightness escalates with a `0 0 16px rgba(99, 102, 241, 0.4)` bloom.
- **Secondary / Ghost:** Background `rgba(255, 255, 255, 0.03)`, text `#F8FAFC`, border `1px solid rgba(255, 255, 255, 0.1)`. On hover, background transitions to `rgba(255, 255, 255, 0.07)`.
- **AI Synthesis Trigger:** Dual-gradient border (`#6366F1` to `#8B5CF6`) around an obsidian core, containing an icon prefix and text set in `Geist`.

### Micro-Cards
Modular information units constructed on Level 1 elevation. Cards feature a 1px border (`rgba(255, 255, 255, 0.07)`), standard internal padding of `space-md` (`0.75rem`), and strict header-body-metadata stacking. When targeted or processing, the card's border illuminates into Indigo.

### Ethical AI & Grounding Badges
Pill-shaped capsules (`border-radius: 9999px`) utilizing `label-sm` in `JetBrains Mono`:
- **Privacy Verified:** Emerald tint `rgba(16, 185, 129, 0.12)`, text `#34D399`, border `1px solid rgba(16, 185, 129, 0.3)`. Accompanied by a 6px solid emerald dot.
- **Source Grounded:** Slate-violet tint `rgba(139, 92, 246, 0.12)`, text `#C4B5FD`, border `1px solid rgba(139, 92, 246, 0.3)`. Supports expandable origin footnotes on tap.

### Productivity Tags
Compact category chips for prioritization, project scopes, and automation rules. Styled with zero shadow, neutral surface fill (`#1E293B`), text `#94A3B8`, border `1px solid rgba(255, 255, 255, 0.06)`, and uppercase tracking via `label-sm`.

### Input Fields & Command Prompts
- **Standard Input:** Height 36px (desktop) / 44px (mobile), background `#090D16`, border `1px solid #334155`, text `#F8FAFC`, placeholder `#475569`. Focused state triggers border `#6366F1` with no offset ring.
- **Synthetix Command Bar:** Floated or docked natural language input. Elevated with background `#0F172AB3` (backdrop blur 20px), active border gradient, embedded model selector chip on the left, and micro-action hotkeys (`⌘K`) on the right.

### Checkboxes & Selection Controls
Square 16x16px boxes with `0.125rem` corners. Unchecked state: `1.5px solid #475569`, background transparent. Checked state: `#6366F1` background, check glyph rendered crisp white. Radio buttons follow identical logic with 50% circular geometry.

### Citations & Source Drawers
Inline superscript pills inside AI summaries linking directly to enterprise documents. Tapping a citation opens an anchored contextual drawer displaying exact quote spans, document security level, and date indexed.