---
name: Obsidian Kinetic
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#ffb783'
  on-tertiary: '#4f2500'
  tertiary-container: '#d97721'
  on-tertiary-container: '#452000'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#ffdcc5'
  tertiary-fixed-dim: '#ffb783'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#703700'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  code-badge:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  caption-mono:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 3rem
---

## Brand & Style

This design system expresses a forward-leaning, high-precision aesthetic tailored for an elite Cloud & AI Full Stack Engineer. The emotional response targets technical recruiters, engineering leaders, and founders: immediate credibility, architectural rigor, and taste.

The visual direction merges **Minimalist Precision** with **Deep Glassmorphism** and subtle luminescence. It avoids juvenile gaming tropes, prioritizing dense information hierarchy, restrained ambient lighting, and razor-sharp typographic discipline. Interfaces feel like a high-performance developer console or an enterprise cloud runtime environment—engineered, luminous, and measured.

## Colors

The palette relies on deep abyssal dark tones layered to produce structural depth without pure black voids. 

- **Primary (`#6366F1` - Electric Indigo):** Anchors primary actions, focal state outlines, and key metric callouts.
- **Secondary (`#06B6D4` - Cyber Cyan):** Applied to AI/Cloud status indicators, pipeline telemetry, and subtle gradient highlights paired with Indigo.
- **Neutral Canvas (`#0B0F19` - Obsidian Dark):** Canvas baseline.
- **Surface Elevation Levels:**
  - `surface-base`: `#0B0F19`
  - `surface-card`: `#111827` (with 60-80% alpha for frosted glass effects)
  - `surface-elevated`: `#1F2937`
  - `surface-border`: `rgba(255, 255, 255, 0.08)`
  - `surface-border-focus`: `rgba(99, 102, 241, 0.4)`
- **Text & Foreground:**
  - `text-primary`: `#F9FAFB`
  - `text-secondary`: `#9CA3AF`
  - `text-muted`: `#6B7280`

## Typography

The typographic hierarchy enforces a tripartite separation of concern:
1. **Plus Jakarta Sans** provides geometric precision and architectural weight to all section titles and headlines.
2. **Inter** ensures high readability across narrative project breakdowns, system architecture descriptions, and credentials.
3. **JetBrains Mono** surfaces all computational metadata, API payloads, stack specifications, timeline metadata, and technical badges.

Maintain tight negative tracking on display sizes to create an editorial, modern tech aesthetic. Avoid pure white typography on large paragraphs—use `#E5E7EB` or `#9CA3AF` to prevent visual fatigue against dark surfaces.

## Layout & Spacing

The portfolio is structured on a 12-column responsive fluid grid with a maximum content bound of `1280px`.

- **Desktop (>= 1024px):** 12-column layout, `1.5rem` gutters, and `2rem` outer padding. Projects utilize an alternating 7/5 column split for preview media and technical deep-dives.
- **Tablet (768px - 1023px):** 8-column layout, collapsed sidebars, `1.5rem` outer margins. Cards conform to a 2-column pattern.
- **Mobile (< 768px):** 4-column layout, `1rem` gutters, and `1.25rem` outer canvas padding. Grids reflow strictly into single-column stacks with edge-aligned timeline nodes.

Vertical section cadence is generous, adhering to an 8px base rhythm with `space-xl` (`3rem`) for component groupings and `5rem` to `7rem` between portfolio sections.

## Elevation & Depth

Visual depth is achieved through **glassmorphic translucency, ambient rim lighting, and subtle luminescence**, avoiding heavy opaque drop shadows.

- **Level 0 (Canvas):** Pure `#0B0F19` background with optional static SVG grid or noise pattern at 3% opacity.
- **Level 1 (Cards & Modules):** Background `rgba(17, 24, 39, 0.65)`, backdrop filter blur `12px`, border `1px solid rgba(255, 255, 255, 0.07)`.
- **Level 2 (Interactive Hover / Popovers):** Background `rgba(31, 41, 55, 0.85)`, backdrop filter blur `16px`, border `1px solid rgba(99, 102, 241, 0.35)`, ambient glow `0 0 24px -4px rgba(99, 102, 241, 0.15)`.
- **Accent Glows:** Conic and radial gradients (`rgba(99, 102, 241, 0.12)` blended into `rgba(6, 182, 212, 0.08)`) placed behind featured projects to introduce atmospheric spatial presence.

## Shapes

The design uses a refined curvature profile (`roundedness: 2`). This provides a tailored `8px` (`0.5rem`) radius for inputs, micro-tags, and buttons, extending to `16px` (`1rem`) on parent project cards and timeline modules. 

Key interactive items like status indicators and specialized pill chips utilize fully rounded capsules to contrast against strict, structural UI grids.

## Components

### Buttons & Interactive CTAs
- **Primary Action:** Solid background with a gradient transition from `#6366F1` to `#4F46E5`. Features a `1px` inner top highlight `rgba(255, 255, 255, 0.2)` and subtle outer shadow `0 4px 14px rgba(99, 102, 241, 0.3)`. Text is semi-bold with `0.5rem` border radius.
- **Secondary / Glass CTA:** Background `rgba(255, 255, 255, 0.03)`, border `1px solid rgba(255, 255, 255, 0.12)`, text `#F9FAFB`. Hover state introduces cyan edge-tinting `rgba(6, 182, 212, 0.4)` and background illumination `rgba(255, 255, 255, 0.06)`.

### Tech Stack Badges & Chips
- Rendered in **JetBrains Mono** (`code-badge`).
- Semi-transparent fills (`rgba(99, 102, 241, 0.08)` for primary stack, `rgba(6, 182, 212, 0.08)` for cloud/infra).
- Border: `1px solid rgba(255, 255, 255, 0.08)`.
- Includes leading dot icon or micro brand glyph (e.g., Python, Kubernetes, PyTorch, AWS).

### Project Cards
- Composed of translucent `surface-card` surfaces with frosted glass blur.
- Outer border features a non-uniform gradient highlight: top-left corner reflects subtle light, while bottom-right dissolves into darkness.
- Inner layout houses: Title, metric callout (e.g., *"99.99% Uptime | <40ms Latency"*), summary paragraph, tech chip array, and live terminal preview or demo link.

### Timeline Component (Experience & Education)
- Continuous vertical spine running `1px` width using a gradient line (`rgba(99, 102, 241, 0.3)` down to `rgba(6, 182, 212, 0.1)`).
- Node indicators: 8px concentric glowing dots positioned along the spine. Current active role features an animated ping aura.
- Content block offset by `1.5rem`, displaying role, company, duration (`caption-mono`), key architectural contributions, and quantified outcomes.

### Input Fields & Contact Elements
- Surface: `#0B0F19` with a `1px solid rgba(255, 255, 255, 0.1)` border.
- Active focus state: Smooth transition to `border-color: #6366F1` accompanied by a localized box-shadow ring `0 0 0 3px rgba(99, 102, 241, 0.15)`.
- Labels rendered in crisp uppercase mono typography (`caption-mono`).